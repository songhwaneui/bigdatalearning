실행 예시
python3 SequenceTagger.py --hparams=hparams/default.json --data=CoNLL-2003
